const ingreso_usuario = () => {
    let usuario;
    let edad;
do {usuario = prompt("Ingresa tu nombre de usuario")}
    while (usuario === "" || usuario === null);  
do {edad = parseInt(prompt("Ingresa tu edad"))}
    while (edad === "" || edad === null || edad <= 0)
if (edad < 18) {
    alert("No puedes ingresar al sitio porque eres menor de edad.")
}
else {
    alert("Bienvenido " + usuario)
}
}
ingreso_usuario();


/*const buscar_trabajo = () => {
    let rubro, salarioMinimo, nivelLaboral, jornadaSemana, jornadaDia, paisEmpleo, ubicacion; 
    
    do {rubro = prompt("Indica en qué rubro, actividad o profesión deseas buscar trabajo")}
    while (rubro === "" || rubro === null || rubro === undefined);
    
   
    do {salarioMinimo = parseInt(prompt("Indica el salario mínimo mensual -en dólares estadounidenses- que pretendes"))}
    while (salarioMinimo ==="" || salarioMinimo === null || salarioMinimo === undefined)
    
    do {nivelLaboral = prompt("Indica el nivel laboral al que aspiras: pasante o trainee; junior; semi-senior; senior o gerente")}
    while (nivelLaboral.toLowerCase() !== "pasante" && nivelLaboral.toLowerCase() !== "trainee" && nivelLaboral.toLowerCase() !== "junior" && nivelLaboral.toLowerCase() !== "semi-senior" && nivelLaboral.toLowerCase() !== "senior" && nivelLaboral.toLowerCase() !== "gerente")    
    
    do {jornadaSemana = parseInt(prompt("Indica la cantidad máxima de horas por semana que estás en que estarías disponible para trabajar"))}
    while (jornadaSemana <= 10 || jornadaSemana === null || jornadaSemana === undefined)
    
    do {jornadaDia = prompt("Indica la cantidad máxima de horas por día en que estarías disponible para trabajar")}
    while (jornadaDia <= 0 || jornadaDia >= jornadaSemana || jornadaDia === null || jornadaDia === undefined)

    do (paisEmpleo = prompt("Indica el país en que deseas buscar trabajo"))
    while (paisEmpleo === "" || paisEmpleo === null || paisEmpleo === undefined)
    
    do {ubicacion = prompt("Indica la ciudad, barrio, zona o calle en que deseas buscar trabajo")}    
    while (ubicacion ==="" || ubicacion === null || ubicacion === undefined)       
    
    alert(`A continuación listaremos los empleos correspondientes a ${rubro}, con un salario mínimo de ${salarioMinimo} dólares estadounidenses, correspondientes al nivel laboral de ${nivelLaboral},
    con una jornada semanal máxima de ${jornadaSemana} horas, una jornada diaria máxima de ${jornadaDia} horas, y que se encuentren dentro de ${ubicacion} en el país ${paisEmpleo}.`)
}*/

class Empleo {
    constructor (rubro, salarioMinimo, nivelLaboral, jornadaSemana, jornadaDia, paisEmpleo, ubicacion) {
        this.rubro = rubro;
        this.salarioMinimo = salarioMinimo;
        this.nivelLaboral = nivelLaboral;
        this.jornadaSemana = jornadaSemana;
        this.jornadaDia = jornadaDia;
        this.paisEmpleo = paisEmpleo;
        this.ubicacion = ubicacion;
    }

    mostrarEmpleo () {
        alert(`A continuación listaremos los empleos correspondientes a ${this.rubro}, con un salario mínimo de ${this.salarioMinimo} dólares estadounidenses, correspondientes al nivel laboral de ${this.nivelLaboral},
        con una jornada semanal máxima de ${this.jornadaSemana} horas, una jornada diaria máxima de ${this.jornadaDia} horas, y que se encuentren dentro de ${this.ubicacion} en el país ${this.paisEmpleo}`)
    }

}

let empleos = [];

const empleo1 = new Empleo  ("programador", 3000, "senior", 50, 10, "Unión Europea", "cualquier zona")
empleo1.mostrarEmpleo()

const empleo2 = new Empleo ("programador", 800, "junior", 48, 10, "Estados Unidos", "Florida")
empleo2.mostrarEmpleo()

const empleo3 = new Empleo ("diseñador UX/UI", 1000, "semi-senior", 40, 8, "España", "Barcelona")
empleo3.mostrarEmpleo()

const empleo4 = new Empleo ("marketing digital", 2000, "senior", 44, 9, "Brasil", "cualquier zona")
empleo4.mostrarEmpleo()

empleos.push(empleo1, empleo2, empleo3, empleo4)
console.table(empleos)

const empleoInteractivo = new Empleo (prompt("Indica en qué rubro, actividad o profesión deseas buscar trabajo"), 
                                parseInt(prompt("Indica el salario mínimo mensual -en dólares estadounidenses- que pretendes")),
                                prompt("Indica el nivel laboral al que aspiras: pasante o trainee; junior; semi-senior; senior o gerente"),
                                parseInt(prompt("Indica la cantidad máxima de horas por semana que estás en que estarías disponible para trabajar")),
                                prompt("Indica la cantidad máxima de horas por día en que estarías disponible para trabajar"),
                                prompt("Indica el país en que deseas buscar trabajo"), 
                                prompt("Indica la ciudad, barrio, zona o calle en que deseas buscar trabajo"))
empleoInteractivo.mostrarEmpleo()

empleos.push(empleoInteractivo)
console.table(empleos)


const empleosProgramación = empleos.filter(empleo => empleo.rubro.includes("programa"))
console.table(empleosProgramación)

const empleo5 = new Empleo ("programador back-end", 4000, "senior", 48, 10, "Estados Unidos", "Florida")

empleosProgramación.push(empleo5)
console.table(empleosProgramación)




