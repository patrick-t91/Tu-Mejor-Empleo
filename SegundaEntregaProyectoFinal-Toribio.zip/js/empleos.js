let listaEmpleos = []

class Empleo {
    constructor (rubro, salario, nivelLaboral, jornadaSemana, jornadaDia, paisEmpleo, ubicacion) {
        this.rubro = rubro;
        this.salario = salario;
        this.nivelLaboral = nivelLaboral;
        this.jornadaSemana = jornadaSemana;
        this.jornadaDia = jornadaDia;
        this.paisEmpleo = paisEmpleo;
        this.ubicacion = ubicacion;
    }
}

const empleo1 = new Empleo  ("Programador Front-End", 3500, "senior", 50, 10, "República Checa", "Praga")
const empleo2 = new Empleo ("Programador Front-End", 800, "junior", 48, 10, "Estados Unidos", "Seattle")
const empleo3 = new Empleo ("Diseñador UX/UI", 1000, "semi-senior", 40, 8, "España", "Barcelona")
const empleo4 = new Empleo ("Marketing digital", 2000, "senior", 44, 9, "Brasil", "San Pablo")
const empleo5 = new Empleo  ("Programador JavaScript", 3000, "senior", 50, 10, "Italia", "Roma")
const empleo6 = new Empleo ("Programador back-end", 800, "junior", 48, 10, "Estados Unidos", "Boston")
const empleo7 = new Empleo ("Diseñador UX/UI", 2800, "senior", 48, 10, "España", "Granada")
const empleo8 = new Empleo ("Marketing digital", 700, "junior", 44, 9, "Brasil", "Río de Janeiro")
const empleo9 = new Empleo  ("Programador front-end", 3000, "senior", 50, 10, "España", "Málaga")
const empleo10 = new Empleo ("Programador", 800, "junior", 48, 10, "Estados Unidos", "Nueva York")
const empleo11 = new Empleo  ("Programador Front-End", 1500, "semi-senior", 40, 8, "Argentina", "Buenos Aires")
const empleo12 = new Empleo ("Diseñador UX/UI", 2000, "senior", 50, 10, "Estados Unidos", "Ohio")
const empleo13 = new Empleo ("Diseñador UX/UI", 1400, "semi-senior", 40, 8, "Francia", "París")
const empleo14 = new Empleo ("Product Manager", 2400, "semi-senior", 44, 8, "Alemania", "Hamburgo")
const empleo15 = new Empleo  ("Programador Back-End", 3600, "senior", 50, 10, "Reino Unido", "Londres")
const empleo16 = new Empleo ("Programador Back-End", 1000, "junior", 44, 10, "Estados Unidos", "Miami")
const empleo17 = new Empleo ("Marketing Digital", 3000, "senior", 48, 8, "España", "Madrid")
const empleo18 = new Empleo ("Programador Front-End", 700, "junior", 44, 9, "Argentina", "Rosario")
const empleo19 = new Empleo  ("Programador front-end", 3500, "senior", 50, 10, "España", "Barcelona")
const empleo20 = new Empleo ("Programador", 800, "junior", 48, 8, "Chile", "Santiago de Chile")
const empleo21 = new Empleo  ("E-Commerce", 3500, "senior", 50, 10, "Alemania", "Munich")
const empleo22 = new Empleo ("Project Manager", 4000, "senior", 50, 10, "Estados Unidos", "Texas")
const empleo23 = new Empleo ("Diseñador UX/UI", 2000, "semi-senior", 48, 8, "Nueva Zelanda", "Auckland")
const empleo24 = new Empleo ("Marketing digital", 3500, "senior", 50, 9, "Nueva Zelanda", "Wellington")
const empleo25 = new Empleo  ("Programador Back-End", 800, "junior", 50, 10, "Francia", "París")
const empleo26 = new Empleo ("Programador Java", 800, "junior", 48, 10, "México", "México DF")
const empleo27 = new Empleo ("Diseñador UX/UI", 1600, "semi-senior", 48, 10, "Argentina", "Córdoba")
const empleo28 = new Empleo ("Marketing digital", 3000, "senior", 48, 10, "Reino Unido", "Manchester")
const empleo29 = new Empleo  ("Programador Python", 3000, "senior", 50, 10, "Italia", "Milán")
const empleo30 = new Empleo ("Programador Java", 800, "junior", 44, 10, "Argentina", "Buenos Aires")
const empleo31 = new Empleo  ("Diseñador UX/UI", 2800, "senior", 44, 8, "Portugal", "Lisboa")
const empleo32 = new Empleo ("Programador Front-End", 800, "junior", 40, 7, "Canadá", "Toronto")
const empleo33 = new Empleo ("Diseñador UX/UI", 1400, "semi-senior", 44, 8, "España", "Madrid")
const empleo34 = new Empleo ("Marketing digital", 4000, "senior", 50, 9, "Chile", "Santiago de Chile")
const empleo35 = new Empleo  ("Programador Back-End", 2000, "semi-senior", 48, 8, "Argentina", "Buenos Aires")
const empleo36 = new Empleo ("Programador back-end", 800, "junior", 44, 8, "Argentina", "Buenos Aires")
const empleo37 = new Empleo ("Diseñador UX/UI", 2800, "senior", 48, 10, "España", "Granada")
const empleo38 = new Empleo ("Programador front-end", 600, "junior", 44, 9, "Australia", "Adelaide")
const empleo39 = new Empleo  ("Programador front-end", 3000, "senior", 50, 10, "Francia", "Toulouse")
const empleo40 = new Empleo ("Marketing digital", 3800, "senior", 48, 10, "Estados Unidos", "Nueva York")
const empleo41 = new Empleo  ("Programador Front-End", 3500, "senior", 48, 8, "Canadá", "Montreal")
const empleo42 = new Empleo ("Programador Front-End", 800, "junior", 48, 10, "Estados Unidos", "Chicago")
const empleo43 = new Empleo ("Diseñador UX/UI", 1500, "semi-senior", 48, 8, "España", "Valencia")
const empleo44 = new Empleo ("Marketing digital", 4000, "senior", 48, 9, "Portugal", "Lisboa")
const empleo45 = new Empleo  ("Programador Python", 3300, "senior", 50, 10, "Estados Unidos", "Denver")
const empleo46 = new Empleo ("Programador back-end", 2800, "semi-senior", 44, 8, "Estados Unidos", "Boston")
const empleo47 = new Empleo ("Diseñador UX/UI", 2800, "semi-senior", 48, 8, "Brasil", "San Pablo")
const empleo48 = new Empleo ("Marketing digital", 700, "junior", 44, 8, "Brasil", "Río de Janeiro")
const empleo49 = new Empleo  ("Programador front-end", 3000, "senior", 48, 8, "Holanda", "Amsterdam")
const empleo50 = new Empleo ("Programador back-end", 3000, "semi-senior", 48, 10, "Alemania", "Berlín")

listaEmpleos.push(empleo1, empleo2, empleo3, empleo4, empleo5, empleo6, empleo7, empleo8, empleo9, empleo10, empleo11, empleo12, empleo13, empleo14, empleo15, empleo16, empleo17, empleo18, empleo19, empleo20, empleo21, empleo22, empleo23, empleo24, empleo25, empleo26, empleo27, empleo28, empleo29, empleo30, empleo31, empleo32, empleo33, empleo34, empleo35, empleo36, empleo37, empleo38, empleo39, empleo40, empleo41, empleo42, empleo43, empleo44, empleo45, empleo46, empleo47, empleo48, empleo49, empleo50)




