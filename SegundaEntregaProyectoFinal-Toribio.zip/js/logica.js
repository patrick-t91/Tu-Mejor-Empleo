const tipoEmpleo = d.createElement("input")
        tipoEmpleo.id = "buscarempleo"
        tipoEmpleo.type = "text"
        tipoEmpleo.placeholder = "Profesión o empleo"
        agregarNodoHijo("busqueda", tipoEmpleo)
 
const salarioMinimo = d.createElement("input")
        salarioMinimo.id = "salariominimo"
        salarioMinimo.type = "text"
        salarioMinimo.placeholder = "Salario mínimo pretendido "
        agregarNodoHijo("busqueda", salarioMinimo)

const nivelLaboral = d.createElement("input")
        nivelLaboral.id = "nivellaboral"
        nivelLaboral.type = "text"
        nivelLaboral.placeholder = "Nivel laboral"
        agregarNodoHijo("busqueda", nivelLaboral)

const jornadaSemana = d.createElement("input")
        jornadaSemana.id = "jornadasemana"
        jornadaSemana.type = "number"
        jornadaSemana.placeholder = "Jornada máxima semanal"
        agregarNodoHijo("busqueda", jornadaSemana)
        
const jornadaDia = d.createElement("input")
        jornadaDia.id = "jornadadia"
        jornadaDia.type = "number"
        jornadaDia.placeholder = "Jornada máxima diaria"
        agregarNodoHijo("busqueda", jornadaDia)   

const paisEmpleo = d.createElement("input")
        paisEmpleo.id = "paisempleo"
        paisEmpleo.type = "text"
        paisEmpleo.placeholder = "País del empleo"
        agregarNodoHijo("busqueda", paisEmpleo)

const ubicacion = d.createElement("input")
        ubicacion.id = "ubicacion"
        ubicacion.type = "text"
        ubicacion.placeholder = "Región o área"
        agregarNodoHijo("busqueda", ubicacion)

const buttonBuscar = d.createElement("button")
        buttonBuscar.id ="btnBuscar"
        buttonBuscar.innerText = "Buscar empleo"
        agregarNodoHijo("busqueda", buttonBuscar)

const filtrar = (e) => {
        return (
        (!tipoEmpleo.value || e.rubro.toUpperCase().includes(tipoEmpleo.value.toUpperCase())) && 
        (!salarioMinimo.value || e.salario >= salarioMinimo.value) &&
        (!nivelLaboral.value || e.nivelLaboral.toUpperCase().includes(nivelLaboral.value.toUpperCase())) &&
        (!jornadaSemana.value || e.jornadaSemana <= jornadaSemana.value) &&
        (!jornadaDia.value || e.jornadaDia <= jornadaDia.value) &&
        (!paisEmpleo.value || e.paisEmpleo.toUpperCase().includes(paisEmpleo.value.toUpperCase())) &&
        (!ubicacion.value || e.ubicacion.toUpperCase().includes(ubicacion.value.toUpperCase()))
        )     
}        

const filtrarEmpleos = () => {
        let empleosFiltrados = listaEmpleos.filter(filtrar)
        empleosBuscados.innerHTML = "" 
        for (empleo of empleosFiltrados) {
        let fila =      `<tr>
                                <td>${empleo.rubro}</td>
                                <td>${empleo.salario} USD</td>
                                <td>${empleo.nivelLaboral}</td>
                                <td>${empleo.jornadaSemana} horas</td>    
                                <td>${empleo.jornadaDia} horas</td>
                                <td>${empleo.paisEmpleo}</td> 
                                <td>${empleo.ubicacion}</td>   
                        </tr>`
                        empleosBuscados.innerHTML += fila
                        ls.setItem("Empleo filtrado de " + tipoEmpleo.value + " " + parseInt(ls.length + 1), JSON.stringify(empleo))
        }
}

buttonBuscar.addEventListener("click", filtrarEmpleos)

function foco(campo) {
        campo.style.backgroundColor = "lightblue"
}

function normal(campo) {
        campo.style.backgroundColor = "white"
    } 

    // Focus
tipoEmpleo.addEventListener("focus", () => {foco(tipoEmpleo)})
salarioMinimo.addEventListener("focus", () => {foco(salarioMinimo)})
nivelLaboral.addEventListener("focus", () => {foco(nivelLaboral)})
jornadaDia.addEventListener("focus", () => {foco(jornadaDia)})
jornadaSemana.addEventListener("focus", () => {foco(jornadaSemana)})
paisEmpleo.addEventListener("focus", () => {foco(paisEmpleo)})
ubicacion.addEventListener("focus", () => {foco(ubicacion)})

    // Blur
tipoEmpleo.addEventListener("blur", () => {normal(tipoEmpleo)})
salarioMinimo.addEventListener("blur", () => {normal(salarioMinimo)})
nivelLaboral.addEventListener("blur", () => {normal(nivelLaboral)})
jornadaDia.addEventListener("blur", () => {normal(jornadaDia)})
jornadaSemana.addEventListener("blur", () => {normal(jornadaSemana)})
paisEmpleo.addEventListener("blur", () => {normal(paisEmpleo)})
ubicacion.addEventListener("blur", () => {normal(ubicacion)})