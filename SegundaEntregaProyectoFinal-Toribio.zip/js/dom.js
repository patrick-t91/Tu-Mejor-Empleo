const d = document
const ls = localStorage
const empleosBuscados = d.getElementById("lista-empleos")

const agregarNodoHijo = (nodoPadre, nodoHijo) => {
    const np = d.getElementById(nodoPadre)
    np.appendChild(nodoHijo)
}

const espaciadoBusqueda = (campo) => {
    campo.style.padding = 1
}

