

// Posible base de datos de usuarios para validar contraseña
let usuarios = [
    {"usuario": "Patricio",
    "contraseña": "patricio123"},
    {"usuario": "Pablo",
    "contraseña": "pablo123"},
    {"usuario": "Matias",
    "contraseña": "matias123"},
    {"usuario": "Juan",
    "contraseña": "juan123"}
]

// Ingreso de usuarios registrados
const inputUsuario = d.createElement("input")
    inputUsuario.id="usuario"
    inputUsuario.type="text"
    inputUsuario.placeholder="Nombre de usuario"
    agregarNodoHijo("ingreso", inputUsuario)
    

const inputContraseña = d.createElement("input")
    inputContraseña.id="contraseña"
    inputContraseña.type="password"
    inputContraseña.placeholder="Contraseña"
    agregarNodoHijo("ingreso", inputContraseña)

const ingresoSitio = d.createElement("button")
    ingresoSitio.id = "btnIngreso"
    ingresoSitio.innerText = "Ingresar"
    agregarNodoHijo("ingreso", ingresoSitio)
    



// Registro de nuevos usuarios
const inputUsuario2 = d.createElement("input")
    inputUsuario2.id="registrousuario"
    inputUsuario2.type="text"
    inputUsuario2.placeholder="Nombre de usuario"
    agregarNodoHijo("registro", inputUsuario2)

const inputContraseña2 = d.createElement("input")
    inputContraseña2.id="registrocontraseña"
    inputContraseña2.type="password"
    inputContraseña2.placeholder="Contraseña"
    agregarNodoHijo("registro", inputContraseña2)

const registroUsuario = d.createElement("button")
    registroUsuario.id="btnRegistro"
    registroUsuario.innerText="Registrarse"
    agregarNodoHijo("registro", registroUsuario)